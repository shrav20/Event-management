<hr class = "footerline"><!--css modified horizontal line-->
<footer>
    <div class = "container">
        <div class = "row">
            <section>
                <div class = "footerContent col-md-4"><!--left content-->
                    <p class = "footerContent1">
                        <strong>D</strong><span class = "small footerSubtext">r</span>
                        <strong>B</strong><span class = "small footerSubtext">abasaheb</span>
                        <strong>A</strong><span class = "small footerSubtext">mbedkar</span>
                        <strong>T</strong><span class = "small footerSubtext">echnological</span>
                        <strong>U</strong><span class = "small footerSubtext">niversity.</span>
                    </p>

                    <p class = "footerSubtext2">
                    Our college Mission is to impart quality technical education and higher moral ethics associated with skilled training to suit the modern day technology with innovative concepts,so as to learn to lead the future with full confidence
                  .
                    </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--middle content-->
                <p> <br>
                 Address: Lonere
                    <br>Raigad,Maharashtra-402103 </p>
                </div>
            </section>
            <section>
                <div class = "footcontent col-md-4"><!--right content-->
                    Follow Us:<br>
                    <a href="https://www.facebook.com/people/Dbatu-live/100064052591252/"><img src = "images/facebook.png"></a>
                    <a href="https://www.instagram.com/dbatu.ac.in/"><img src = "images/instagram.png" width="65px"></a>
                        
                        <a href=""><img src = "images/youtube.png"></a>
                </div>
            </section>
        </div>
    </div>
</footer>